Peyk Kavir Platform — Windows Local Bundle
=========================================

Contents:
- backend/: FastAPI app that serves API + static frontend
- run_windows.bat : One-line script to setup venv and run the app
- sample_data/: sample CSV for upload
- reports/: generated reports will be saved here

Requirements (install on Windows before running):
- Python 3.11+ added to PATH
- (Optional) Git

How to run (PowerShell or CMD):
1. Open PowerShell in this folder as Administrator (if you want to bind low ports).
2. Run:
   run_windows.bat

What the script does:
- creates .venv
- installs Python deps
- starts backend (uvicorn) on port 8000
- frontend is served as static files by the backend at http://localhost:8000/

Endpoints:
- GET /health
- POST /auth/signup  (JSON body: username,password,full_name,role)
- POST /auth/token   (form-data username,password)
- GET /transactions
- POST /transactions/upload-csv  (multipart file)
- POST /reports/generate?period=daily

Files of interest:
- backend/app/: source code for API
- frontend/build/: static frontend that is already prebuilt and served by backend
- sample_data/sample_data.csv: sample transactions for upload

If you want a Windows exe for the backend, run (optional) after setup:
    .venv\Scripts\pip install pyinstaller
    .venv\Scripts\pyinstaller --onefile --add-data "backend/app;app" backend/app/main.py

