@echo off
SETLOCAL
echo Setting up Peyk Kavir Platform (Windows local)

if not exist .venv (
    echo Creating virtual environment...
    python -m venv .venv
)

echo Activating virtual environment...
call .venv\Scripts\activate.bat

echo Installing requirements...
pip install --upgrade pip
pip install -r backend/requirements.txt

echo Ensuring reports and logs directories...
mkdir backend\reports 2>nul
mkdir backend\logs 2>nul

echo Starting the backend with uvicorn (CTRL+C to stop)...
REM Run uvicorn; if you want to run in background, use start "" /B
call .venv\Scripts\uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

ENDLOCAL
