# Optional helper to create sqlite DB and tables for local bundle
from sqlalchemy import create_engine
from app import models, database
engine = database.engine
models.Base.metadata.create_all(bind=engine)
print('sqlite DB & tables created (if not exists).')
