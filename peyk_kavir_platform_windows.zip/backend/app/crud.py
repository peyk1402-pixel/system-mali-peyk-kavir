from sqlalchemy.orm import Session
from . import models, schemas
from passlib.context import CryptContext

pwd = CryptContext(schemes=['bcrypt'], deprecated='auto')

def create_user(db: Session, user: schemas.UserCreate):
    hashed = pwd.hash(user.password)
    db_user = models.User(username=user.username, hashed_password=hashed, full_name=user.full_name, role=user.role)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username==username).first()

def create_transaction(db: Session, tx: schemas.TransactionCreate):
    db_tx = models.Transaction(**tx.dict())
    db.add(db_tx)
    db.commit()
    db.refresh(db_tx)
    return db_tx

def list_transactions(db: Session, skip=0, limit=100):
    return db.query(models.Transaction).order_by(models.Transaction.created_at.desc()).offset(skip).limit(limit).all()
