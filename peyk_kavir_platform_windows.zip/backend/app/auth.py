from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from .. import crud, database, schemas
from fastapi.security import OAuth2PasswordRequestForm

router = APIRouter(prefix='/auth', tags=['auth'])
pwd = CryptContext(schemes=['bcrypt'], deprecated='auto')

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post('/signup', response_model=schemas.UserOut)
def signup(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    existing = db.query(crud.models.User).filter(crud.models.User.username==payload.username).first()
    if existing:
        raise HTTPException(status_code=400, detail='username exists')
    user = crud.create_user(db, payload)
    return user

@router.post('/token')
def token(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = crud.get_user_by_username(db, form_data.username)
    if not user or not pwd.verify(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail='Incorrect credentials')
    # simple token (not JWT) for local use
    return {'access_token': f'token-{user.username}', 'token_type': 'bearer'}
