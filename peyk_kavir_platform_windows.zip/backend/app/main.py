from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from . import models, database
from .routers import auth, transactions, reports, users
import os

models.Base.metadata.create_all(bind=database.engine)

app = FastAPI(title="Peyk Kavir Platform (local bundle)")

# Mount static frontend (prebuilt)
frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend_build")
if os.path.isdir(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True), name="frontend")

app.include_router(auth.router)
app.include_router(users.router)
app.include_router(transactions.router)
app.include_router(reports.router)

@app.get("/health")
def health():
    return {"status": "ok"}
