from fastapi import APIRouter, Depends
from .. import database, crud, schemas
from sqlalchemy.orm import Session

router = APIRouter(prefix='/users', tags=['users'])

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get('/')
def list_users(db: Session = Depends(get_db)):
    return db.query(crud.models.User).all()
