from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from .. import database, crud, schemas
from sqlalchemy.orm import Session
import pandas as pd, io

router = APIRouter(prefix='/transactions', tags=['transactions'])

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get('/')
def list_tx(db: Session = Depends(get_db)):
    return crud.list_transactions(db)

@router.post('/upload-csv')
async def upload_csv(file: UploadFile = File(...), db: Session = Depends(get_db)):
    contents = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(contents))
    except Exception as e:
        raise HTTPException(status_code=400, detail='Invalid CSV')
    inserted = 0
    for _, row in df.iterrows():
        tx = schemas.TransactionCreate(
            tx_id=str(row.get('tx_id','')),
            account=str(row.get('account','')),
            amount=float(row.get('amount',0)),
            currency=str(row.get('currency','IRR')),
            type=str(row.get('type','')),
            source=str(row.get('source','')),
            metadata={}
        )
        crud.create_transaction(db, tx)
        inserted += 1
    return {'inserted': inserted}
