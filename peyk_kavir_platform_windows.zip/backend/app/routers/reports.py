from fastapi import APIRouter
import pandas as pd, os
from datetime import datetime

router = APIRouter(prefix='/reports', tags=['reports'])

@router.post('/generate')
def gen(period: str = 'daily'):
    # read DB via sqlite for local bundle
    try:
        import sqlite3
        conn = sqlite3.connect('peyk_kavir.db')
        df = pd.read_sql_query('SELECT * FROM transactions', conn)
    except Exception:
        # fallback: create sample summary
        df = pd.DataFrame([{'metric':'sample','value':1}])
    os.makedirs('backend/reports', exist_ok=True)
    fname = f'backend/reports/report_{period}_{datetime.utcnow().strftime("%Y%m%d_%H%M%S")}.xlsx'
    df.to_excel(fname, index=False)
    return {'file': fname}
