from pydantic import BaseModel
from typing import Optional, Dict
import datetime

class UserCreate(BaseModel):
    username: str
    password: str
    full_name: Optional[str]
    role: Optional[str] = "support"

class UserOut(BaseModel):
    id: int
    username: str
    full_name: Optional[str]
    role: str
    class Config:
        orm_mode = True

class TransactionCreate(BaseModel):
    tx_id: str
    account: Optional[str]
    amount: float
    currency: Optional[str] = "IRR"
    type: Optional[str]
    source: Optional[str]
    metadata: Optional[Dict] = None

class TransactionOut(TransactionCreate):
    id: int
    created_at: datetime.datetime
    class Config:
        orm_mode = True
